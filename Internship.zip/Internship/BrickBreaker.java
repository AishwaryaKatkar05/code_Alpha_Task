import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BrickBreaker extends JFrame implements ActionListener {
    private final int WIDTH = 800;
    private final int HEIGHT = 600;
    private final int PADDLE_WIDTH = 100;
    private final int PADDLE_HEIGHT = 20;
    private final int BALL_DIAMETER = 20;
    private final int BRICK_WIDTH = 60;
    private final int BRICK_HEIGHT = 30;
    private final int NUM_BRICKS = 50;
    private final int PADDLE_SPEED = 20;

    private Timer timer;
    private int paddleX, ballX, ballY, ballXDir, ballYDir;
    private boolean playing;
    private Rectangle paddle;
    private Rectangle[] bricks;

    public BrickBreaker() {
        setTitle("Brick Breaker");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        paddleX = WIDTH / 2 - PADDLE_WIDTH / 2;
        ballX = WIDTH / 2 - BALL_DIAMETER / 2;
        ballY = HEIGHT / 2 - BALL_DIAMETER / 2;
        ballXDir = 1;
        ballYDir = -1;
        playing = true;

        paddle = new Rectangle(paddleX, HEIGHT - PADDLE_HEIGHT - 30, PADDLE_WIDTH, PADDLE_HEIGHT);
        bricks = new Rectangle[NUM_BRICKS];

        int brickX = 10;
        int brickY = 50;
        for (int i = 0; i < NUM_BRICKS; i++) {
            bricks[i] = new Rectangle(brickX, brickY, BRICK_WIDTH, BRICK_HEIGHT);
            brickX += BRICK_WIDTH + 10;
            if (brickX >= WIDTH - BRICK_WIDTH) {
                brickX = 10;
                brickY += BRICK_HEIGHT + 10;
            }
        }

        timer = new Timer(10, this);
        timer.start();

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_LEFT) {
                    if (paddleX > 0)
                        paddleX -= PADDLE_SPEED;
                } else if (key == KeyEvent.VK_RIGHT) {
                    if (paddleX < WIDTH - PADDLE_WIDTH)
                        paddleX += PADDLE_SPEED;
                }
                paddle.setLocation(paddleX, HEIGHT - PADDLE_HEIGHT - 30);
            }
        });

        setFocusable(true);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        g.setColor(Color.BLACK);
        g.fillRect(0, 0, WIDTH, HEIGHT);

        g.setColor(Color.WHITE);
        g.fillOval(ballX, ballY, BALL_DIAMETER, BALL_DIAMETER);
        g.fillRect(paddleX, HEIGHT - PADDLE_HEIGHT - 30, PADDLE_WIDTH, PADDLE_HEIGHT);

        for (int i = 0; i < NUM_BRICKS; i++) {
            if (bricks[i] != null) {
                g.setColor(Color.RED);
                g.fillRect(bricks[i].x, bricks[i].y, BRICK_WIDTH, BRICK_HEIGHT);
            }
        }

        if (!playing) {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 30));
            g.drawString("Game Over", WIDTH / 2 - 100, HEIGHT / 2 - 15);
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (playing) {
            ballX += ballXDir;
            ballY += ballYDir;

            if (ballX <= 0 || ballX >= WIDTH - BALL_DIAMETER)
                ballXDir *= -1;

            if (ballY <= 0)
                ballYDir *= -1;

            if (ballY >= HEIGHT - BALL_DIAMETER - PADDLE_HEIGHT - 30 && ballX >= paddleX && ballX <= paddleX + PADDLE_WIDTH)
                ballYDir *= -1;

            for (int i = 0; i < NUM_BRICKS; i++) {
                if (bricks[i] != null && bricks[i].intersects(new Rectangle(ballX, ballY, BALL_DIAMETER, BALL_DIAMETER))) {
                    bricks[i] = null;
                    ballYDir *= -1;
                }
            }

            if (ballY >= HEIGHT - BALL_DIAMETER) {
                playing = false;
                timer.stop();
            }

            repaint();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new BrickBreaker().setVisible(true);
            }
        });
    }
}

