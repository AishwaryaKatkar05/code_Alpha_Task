import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class URLShortener {
    private Map<String, String> urlMap;
    private static final String BASE_URL = "http://short.url/";
    private MessageDigest md;

    public URLShortener() {
        urlMap = new HashMap<>();
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    public String shortenURL(String longURL) {
        byte[] hashBytes = md.digest(longURL.getBytes());
        String hashString = Base64.getUrlEncoder().encodeToString(hashBytes);
        String shortURL = BASE_URL + hashString.substring(0, 8); // Generate a short URL using first 8 characters of hashString
        urlMap.put(shortURL, longURL);
        return shortURL;
    }

    public String expandURL(String shortURL) {
        return urlMap.get(shortURL);
    }

    public static void main(String[] args) {
        URLShortener shortener = new URLShortener();

        // Test the URL shortening service
        String longURL = "https://www.example.com/very/long/url";
        String shortURL = shortener.shortenURL(longURL);
        System.out.println("Shortened URL: " + shortURL);

        String originalURL = shortener.expandURL(shortURL);
        System.out.println("Expanded URL: " + originalURL);
    }
}

