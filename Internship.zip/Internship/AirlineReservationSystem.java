import java.util.ArrayList;
import java.util.Scanner;

class Flight {
    private String flightNumber;
    private String departure;
    private String destination;
    private int availableSeats;

    public Flight(String flightNumber, String departure, String destination, int availableSeats) {
        this.flightNumber = flightNumber;
        this.departure = departure;
        this.destination = destination;
        this.availableSeats = availableSeats;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getDeparture() {
        return departure;
    }

    public String getDestination() {
        return destination;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void bookSeats(int numSeats) {
        if (numSeats <= availableSeats) {
            availableSeats -= numSeats;
            System.out.println("Seats booked successfully!");
        } else {
            System.out.println("Not enough seats available!");
        }
    }
}

class ReservationSystem {
    private ArrayList<Flight> flights;

    public ReservationSystem() {
        flights = new ArrayList<>();
        // Add some sample flights
        flights.add(new Flight("ABC123", "New York", "Los Angeles", 150));
        flights.add(new Flight("XYZ456", "Chicago", "Miami", 200));
    }

    public void displayFlights() {
        System.out.println("Available Flights:");
        for (Flight flight : flights) {
            System.out.println(flight.getFlightNumber() + ": " + flight.getDeparture() + " to " + flight.getDestination() +
                    ", Available Seats: " + flight.getAvailableSeats());
        }
    }

    public void bookFlight(String flightNumber, int numSeats) {
        for (Flight flight : flights) {
            if (flight.getFlightNumber().equals(flightNumber)) {
                flight.bookSeats(numSeats);
                return;
            }
        }
        System.out.println("Flight with number " + flightNumber + " not found!");
    }
}

public class AirlineReservationSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ReservationSystem reservationSystem = new ReservationSystem();

        boolean running = true;
        while (running) {
            System.out.println("\n1. Display Flights");
            System.out.println("2. Book a Flight");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    reservationSystem.displayFlights();
                    break;
                case 2:
                    System.out.print("Enter the flight number: ");
                    String flightNumber = scanner.nextLine();
                    System.out.print("Enter the number of seats to book: ");
                    int numSeats = scanner.nextInt();
                    reservationSystem.bookFlight(flightNumber, numSeats);
                    break;
                case 3:
                    running = false;
                    System.out.println("Thank you for using the Airline Reservation System!");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }

        scanner.close();
    }
}

