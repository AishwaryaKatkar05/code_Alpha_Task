import java.util.Scanner;

public class ATMSystem {
    private static final String CORRECT_USER_ID = "user123";
    private static final String CORRECT_PIN = "1234";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the ATM System");

        // Prompt user for user ID and PIN
        System.out.print("Enter your user ID: ");
        String userId = scanner.nextLine();

        System.out.print("Enter your PIN: ");
        String pin = scanner.nextLine();

        // Check if user ID and PIN are correct
        if (userId.equals(CORRECT_USER_ID) && pin.equals(CORRECT_PIN)) {
            System.out.println("Login successful. ATM functionalities unlocked.");
            // Call method to unlock ATM functionalities
            unlockATMFunctionalities();
        } else {
            System.out.println("Invalid user ID or PIN. Access denied.");
        }

        scanner.close();
    }

    // Method to unlock ATM functionalities
    public static void unlockATMFunctionalities() {
        // You can implement ATM functionalities here
        System.out.println("ATM functionalities unlocked.");
    }
}

